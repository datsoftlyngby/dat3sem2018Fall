/**
 * Created by tha on 12-10-2017.
 * Based on: "https://medium.com/@pshrmn/a-simple-react-router-v4-tutorial-7f23ff27adf"
 */
import React, { Component } from 'react';
import { Switch, Route, Link } from 'react-router-dom'
import CandidateFacade from '../data/CandidateFacade';
import { Table, Button, Image, Nav, NavItem } from 'react-bootstrap';

import '../css/exam.css';
const cf = new CandidateFacade();
const RoutingDemo = () => (

    <div>
        <Header />
        <Main />
    </div>
);
export default RoutingDemo;

class Header extends Component {
    render() {
        return (
            <div>
                <p>Insert Link Components here </p>
            </div>
        )
    }
};

const Main = () => (
    <main>
        <Switch>
            <p>Insert 3 Route components here</p>
        </Switch>
    </main>
);

//create the Home, Municipalities and Candidates Components here