/**
 * Created by tha on 19-12-2017.
 */
const URL = "http://localhost:4001/electionCandidates/";

export default class CandidateFacade{


    async loadData(){
        const data = await fetch(URL);
        const jsonData = await data.json();
        //const filtered = jsonData.filter((e,idx)=>idx>5 && idx <= 10);
        return jsonData;
    }
    async getCandidate(id){
        const detailURL = URL + id;
        const data = await fetch(detailURL);
        const jsonData = await data.json();
        console.log("getCandidate", jsonData);
        return jsonData;
    }

}
window.data = new CandidateFacade().data;
window.test = "test";
